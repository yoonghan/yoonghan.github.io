/*
//Initiate
mutation {
  powerMgmtTrigger(input:{
    agentIds:[12,13, 99]
    operation:RESTART
  })
}

//Query
{
  powerMgmtStatus(agentId:12)
}

*/
