module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../../../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__("D4/9");


/***/ }),

/***/ "2Hkz":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return HtmlHead; });
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__("HJQg");
/* harmony import */ var styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(styled_jsx_style__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__("cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__("xnum");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _shared_style__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__("wNZo");

"use strict";




var HtmlHead = function HtmlHead(_ref) {
  var title = _ref.title,
      description = _ref.description;
  return react__WEBPACK_IMPORTED_MODULE_1__["createElement"](react__WEBPACK_IMPORTED_MODULE_1__["Fragment"], null, react__WEBPACK_IMPORTED_MODULE_1__["createElement"](next_head__WEBPACK_IMPORTED_MODULE_2___default.a, null, react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    charSet: "utf-8",
    key: "charset",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    name: "viewport",
    content: "width=device-width, initial-scale=1",
    key: "viewport",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    name: "og:title",
    content: "Walcron Coorperation",
    key: "fb_title",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    name: "og:type",
    content: "profile",
    key: "fb_type",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    name: "og:site_name",
    content: "https://www.walcron.com/",
    key: "fb_charset",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    property: "og:image:type",
    content: "image/png",
    key: "fb_image_t",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    property: "og:image:width",
    content: "400",
    key: "fb_image_w",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    property: "og:image:height",
    content: "400",
    key: "fb_image_h",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    name: "og:image",
    content: "https://www.walcron.com/og_image.png",
    key: "fb_image_i",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    name: "og:description",
    content: "Welcome to Walcron Coorperation, Malaysia; a site was built for IT research purposes.",
    key: "fb_image_desc",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    name: "fb:admins",
    content: "walcoorperation@gmail.com",
    key: "fb_image_m",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("title", {
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }, title), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("meta", {
    name: "description",
    content: description,
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("link", {
    rel: "stylesheet",
    href: "https://use.fontawesome.com/releases/v5.5.0/css/all.css",
    key: "font",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  }), react__WEBPACK_IMPORTED_MODULE_1__["createElement"]("link", {
    rel: "stylesheet",
    href: "/css/font.css",
    key: "internalfont",
    className: styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a.dynamic([["1230417743", [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]]])
  })), react__WEBPACK_IMPORTED_MODULE_1__["createElement"](styled_jsx_style__WEBPACK_IMPORTED_MODULE_0___default.a, {
    id: "1230417743",
    dynamic: [_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], _shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"]]
  }, ["html{font-size:12pt;min-width:320px;}", "body{background:".concat(_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* BACKGROUND */ "a"], " url(\"/img/bg/type1.jpg\") no-repeat left bottom;background-size:contain;color:").concat(_shared_style__WEBPACK_IMPORTED_MODULE_3__[/* FOREGROUND */ "d"], ";position:relative;padding:0;margin:0;}")]));
};

/***/ }),

/***/ "D4/9":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "styled-jsx/style"
var style_ = __webpack_require__("HJQg");
var style_default = /*#__PURE__*/__webpack_require__.n(style_);

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__("cDcd");

// EXTERNAL MODULE: ./components/HtmlHead/index.tsx
var HtmlHead = __webpack_require__("2Hkz");

// CONCATENATED MODULE: ./components/Logo.tsx

"use strict";



var Logo_Logo = function Logo(_ref) {
  var _ref$withText = _ref.withText,
      withText = _ref$withText === void 0 ? false : _ref$withText;
  return external_react_["createElement"](external_react_["Fragment"], null, external_react_["createElement"]("div", {
    className: "jsx-596006957" + " " + 'logo-container'
  }, external_react_["createElement"]("img", {
    src: "/static/img/logo/logo-color.svg",
    className: "jsx-596006957"
  }), withText && external_react_["createElement"]("div", {
    className: "jsx-596006957"
  }, " Walcron")), external_react_["createElement"](style_default.a, {
    id: "596006957"
  }, [".logo-container.jsx-596006957 img.jsx-596006957{position:absolute;width:60px;top:10px;display:inline;left:20px;}", ".logo-container.jsx-596006957 div.jsx-596006957{position:absolute;top:20px;font-size:20pt;font-family:arial;left:90px;font-weight:700;}"]));
};

/* harmony default export */ var components_Logo = (Logo_Logo);
// EXTERNAL MODULE: ./shared/style.ts
var style = __webpack_require__("wNZo");

// CONCATENATED MODULE: ./components/ConstructionSplashScreen.tsx

"use strict";




var ConstructionSplashScreen_ConstructionSplashScreen = function ConstructionSplashScreen() {
  return external_react_["createElement"]("div", {
    className: style_default.a.dynamic([["2394504806", [style["j" /* background */]['construction'], style["k" /* fontColor */]['construction-h1'], style["k" /* fontColor */]['construction-h5']]]]) + " " + "construction-splash-screen-container"
  }, external_react_["createElement"]("div", {
    className: style_default.a.dynamic([["2394504806", [style["j" /* background */]['construction'], style["k" /* fontColor */]['construction-h1'], style["k" /* fontColor */]['construction-h5']]]]) + " " + "construction-splash-screen-text-container"
  }, external_react_["createElement"]("div", {
    className: style_default.a.dynamic([["2394504806", [style["j" /* background */]['construction'], style["k" /* fontColor */]['construction-h1'], style["k" /* fontColor */]['construction-h5']]]]) + " " + "banner"
  }, "(404) NOT FOUND"), external_react_["createElement"]("img", {
    src: "/static/img/construction.svg",
    className: style_default.a.dynamic([["2394504806", [style["j" /* background */]['construction'], style["k" /* fontColor */]['construction-h1'], style["k" /* fontColor */]['construction-h5']]]])
  }), external_react_["createElement"]("hr", {
    className: style_default.a.dynamic([["2394504806", [style["j" /* background */]['construction'], style["k" /* fontColor */]['construction-h1'], style["k" /* fontColor */]['construction-h5']]]])
  }), external_react_["createElement"]("div", {
    className: style_default.a.dynamic([["2394504806", [style["j" /* background */]['construction'], style["k" /* fontColor */]['construction-h1'], style["k" /* fontColor */]['construction-h5']]]]) + " " + "footnote"
  }, "Walcron ver 5.0")), external_react_["createElement"](style_default.a, {
    id: "2394504806",
    dynamic: [style["j" /* background */]['construction'], style["k" /* fontColor */]['construction-h1'], style["k" /* fontColor */]['construction-h5']]
  }, [".banner.__jsx-style-dynamic-selector{text-align:center;font-size:2rem;font-family:fantasy,arial,sans-serif;padding-bottom:5px;}", ".footnote.__jsx-style-dynamic-selector{font-size:1rem;text-align:center;font-family:arial,sans-serif;}", "img.__jsx-style-dynamic-selector{display:block;margin-left:auto;margin-right:auto;width:50%;opacity:0.3;max-height:320px;}", "h5.__jsx-style-dynamic-selector{margin:10px 0 0 0;font-weight:normal;font-family:arial;}", "hr.__jsx-style-dynamic-selector{margin:20px 0;border-top:1px solid #90A4AE;}", ".construction-splash-screen-container.__jsx-style-dynamic-selector{position:relative;height:100vh;min-width:320px;background:".concat(style["j" /* background */]['construction'], ";color:#000;}"), ".construction-splash-screen-text-container.__jsx-style-dynamic-selector{position:absolute;top:50%;-webkit-transform:translate(0,-50%);-ms-transform:translate(0,-50%);transform:translate(0,-50%);width:100%;}", ".construction-splash-screen-container.__jsx-style-dynamic-selector h1.__jsx-style-dynamic-selector{font-size:5rem;color:".concat(style["k" /* fontColor */]['construction-h1'], ";text-align:center;}"), ".construction-splash-screen-container.__jsx-style-dynamic-selector h5.__jsx-style-dynamic-selector{font-size:1rem;color:".concat(style["k" /* fontColor */]['construction-h5'], ";text-align:center;}")]));
};

/* harmony default export */ var components_ConstructionSplashScreen = (ConstructionSplashScreen_ConstructionSplashScreen);
// CONCATENATED MODULE: ./pages/_error.tsx






var _error_Index = function Index() {
  return external_react_["createElement"](external_react_["Fragment"], null, external_react_["createElement"](HtmlHead["a" /* HtmlHead */], {
    title: "Not Found",
    description: "Walcron Coorperation is a basic company setup by Yoong Han and Lee Wan for World Wide Web research purposes."
  }), external_react_["createElement"]("div", {
    className: "jsx-1024332323" + " " + 'container'
  }, external_react_["createElement"]("h1", {
    className: "jsx-1024332323"
  }, "Welcome to walcron."), external_react_["createElement"]("h2", {
    className: "jsx-1024332323"
  }, "The page you have requested is not available."), external_react_["createElement"](components_ConstructionSplashScreen, null), external_react_["createElement"](components_Logo, null), external_react_["createElement"]("h3", {
    className: "jsx-1024332323"
  }, "Design by Walcron ( 2019 )")), external_react_["createElement"](style_default.a, {
    id: "1593699405"
  }, ["h1.jsx-1024332323{display:none;}", "h2.jsx-1024332323{display:none;}", "h3.jsx-1024332323{position:absolute;bottom:30px;right:30px;font-family:arial;line-height:0;font-size:0.8rem;font-weight:normal;color:#000;}", "container.jsx-1024332323{position:relative;}"]), external_react_["createElement"](style_default.a, {
    id: "3416829287"
  }, ["html{font-size:12pt;}", "body{padding:0;margin:0;}"]));
};

/* harmony default export */ var _error = __webpack_exports__["default"] = (_error_Index);

/***/ }),

/***/ "HJQg":
/***/ (function(module, exports) {

module.exports = require("styled-jsx/style");

/***/ }),

/***/ "cDcd":
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "wNZo":
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export WHITE */
/* unused harmony export BLACK */
/* unused harmony export GREY */
/* unused harmony export DARKGREY */
/* unused harmony export WHITISH */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "g", function() { return SHADOW; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "d", function() { return FOREGROUND; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return BACKGROUND; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "k", function() { return fontColor; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "j", function() { return background; });
/* unused harmony export fontFamily */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "i", function() { return TABLE_HEADER; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "h", function() { return TABLE_BODY; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "c", function() { return ERROR; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "f", function() { return OUTPUT; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "e", function() { return LINK; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "b", function() { return DIALOG; });
//const PRIMARY_YELLOW = "#FFDE03";
//const PRIMARY_BLUE = "#0336FF";
var PRIMARY_PURPLE = "#FF0266";
var WHITE = "#FFF";
var BLACK = "#000";
var GREY = "#CCC";
var DARKGREY = "#999";
var WHITISH = "#BEBEBE";
var SHADOW = "grey";
var FOREGROUND = WHITISH;
var BACKGROUND = BLACK;
var fontColor = {
  color: WHITE,
  'construction-h1': PRIMARY_PURPLE,
  'construction-h5': BLACK
};
var background = {
  construction: "#ECEFF1"
};
var fontFamily = {
  standard: '"Roboto", arial, serif'
};
var TABLE_HEADER = {
  FOREGROUND: "#FFF",
  BACKGROUND: "#343a40",
  BORDERCOLOR: "#454d55"
};
var TABLE_BODY = {
  BORDER: "1px solid #dee2e6",
  HOVER_BACKGROUND: "#E9E9E9",
  EVEN_BACKGROUND: "#D9D9D9"
};
var ERROR = {
  FOREGROUND: "#F90101",
  FONT_SIZE: "1rem"
};
var OUTPUT = {
  FOREGROUND: "#09F909",
  FONT_SIZE: "1rem"
};
var LINK = {
  FOREGROUND: WHITE,
  BACKGROUND: BLACK
};
var DIALOG = {
  FOREGROUND: WHITE,
  BACKGROUND: BLACK
};

/***/ }),

/***/ "xnum":
/***/ (function(module, exports) {

module.exports = require("next/head");

/***/ })

/******/ });